#
# TABLE STRUCTURE FOR: customers
#

DROP TABLE IF EXISTS `customers`;

CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` enum('1','0') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '1' COMMENT '1=Active | 0=Inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `address`, `created`, `modified`, `status`) VALUES (1, 'Aditya', 'as@g.com', '112444232', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1');
INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `address`, `created`, `modified`, `status`) VALUES (2, 'sad', 'asd@gsk.com', '96541', 'dasas', '2021-02-23 14:18:57', '2021-02-23 14:18:57', '1');
INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `address`, `created`, `modified`, `status`) VALUES (3, 'sa', 'asd@gmao.com', '65486513', 'aldjfads', '2021-02-23 16:32:11', '2021-02-23 16:32:11', '1');
INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `address`, `created`, `modified`, `status`) VALUES (4, 'as', 'as@as.as', 'as', 'as', '2021-03-13 20:38:32', '2021-03-13 20:38:32', '1');
INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `address`, `created`, `modified`, `status`) VALUES (5, 'as', 'as@as.as', '34324', 'aasx', '2021-03-14 13:02:36', '2021-03-14 13:02:36', '1');
INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `address`, `created`, `modified`, `status`) VALUES (6, '', 'asd@asd.co', 'asd', 'adf', '2021-03-22 07:14:25', '2021-03-22 07:14:25', '1');
INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `address`, `created`, `modified`, `status`) VALUES (7, '', 'Sa@sa.a', '352', 'as', '2021-03-22 17:23:44', '2021-03-22 17:23:44', '1');


#
# TABLE STRUCTURE FOR: order_items
#

DROP TABLE IF EXISTS `order_items`;

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(5) NOT NULL,
  `sub_total` float(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `sub_total`) VALUES (1, 1, 2, 1, '5225205.00');
INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `sub_total`) VALUES (2, 2, 1, 2, '40000000.00');
INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `sub_total`) VALUES (3, 3, 1, 1, '65999.00');
INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `sub_total`) VALUES (4, 4, 1, 1, '65999.00');
INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `sub_total`) VALUES (5, 4, 2, 1, '85990.00');
INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `sub_total`) VALUES (6, 5, 1, 3, '197997.00');
INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `sub_total`) VALUES (7, 6, 2, 1, '85990.00');


#
# TABLE STRUCTURE FOR: orders
#

DROP TABLE IF EXISTS `orders`;

CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `grand_total` float(10,2) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` enum('1','0') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '1' COMMENT '1=Active | 0=Inactive',
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `orders` (`id`, `customer_id`, `grand_total`, `created`, `modified`, `status`) VALUES (1, 2, '5225205.00', '2021-02-23 14:18:58', '2021-02-23 14:18:58', '1');
INSERT INTO `orders` (`id`, `customer_id`, `grand_total`, `created`, `modified`, `status`) VALUES (2, 3, '40000000.00', '2021-02-23 16:32:11', '2021-02-23 16:32:11', '1');
INSERT INTO `orders` (`id`, `customer_id`, `grand_total`, `created`, `modified`, `status`) VALUES (3, 4, '65999.00', '2021-03-13 20:38:32', '2021-03-13 20:38:32', '1');
INSERT INTO `orders` (`id`, `customer_id`, `grand_total`, `created`, `modified`, `status`) VALUES (4, 5, '151989.00', '2021-03-14 13:02:36', '2021-03-14 13:02:36', '1');
INSERT INTO `orders` (`id`, `customer_id`, `grand_total`, `created`, `modified`, `status`) VALUES (5, 6, '197997.00', '2021-03-22 07:14:25', '2021-03-22 07:14:25', '1');
INSERT INTO `orders` (`id`, `customer_id`, `grand_total`, `created`, `modified`, `status`) VALUES (6, 7, '85990.00', '2021-03-22 17:23:44', '2021-03-22 17:23:44', '1');


#
# TABLE STRUCTURE FOR: products
#

DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `price` float(10,2) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` enum('1','0') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '1' COMMENT '1=Active | 0=Inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4;

INSERT INTO `products` (`id`, `image`, `name`, `description`, `price`, `created`, `modified`, `status`) VALUES (1, '1.jpeg', 'Asus ROG Strix G15 Core i7 10th Gen', '16 GB/512 GB SSD/Windows 10 Home/6 GB Graphics/NVIDIA GeForce GTX 1660 Ti/144 Hz) G512LU-AL012T Gaming Laptop', '65999.00', '2021-02-22 00:00:00', '2021-02-22 22:30:00', '1');
INSERT INTO `products` (`id`, `image`, `name`, `description`, `price`, `created`, `modified`, `status`) VALUES (2, '4.jpg', 'HP Omen Ryzen 7 Octa Core 4800H', '8 GB/512 GB SSD/Windows 10 Home/4 GB Graphics/NVIDIA GeForce GTX 1650 Ti) 15-en0004AX Gaming Laptop ', '85990.00', '2021-02-22 00:00:00', '2021-02-22 22:30:00', '1');
INSERT INTO `products` (`id`, `image`, `name`, `description`, `price`, `created`, `modified`, `status`) VALUES (3, '5.jpg', 'Lenovo IdeaPad Gaming 3i Core i5 10th Gen', '8 GB/1 TB HDD/256 GB SSD/Windows 10 Home/4 GB Graphics/NVIDIA GeForce GTX 1650 Ti/60 Hz', '65990.00', '2021-02-24 10:36:31', '2021-02-24 00:00:00', '1');
INSERT INTO `products` (`id`, `image`, `name`, `description`, `price`, `created`, `modified`, `status`) VALUES (4, '6.jpg', 'MSI GF63 Thin Core i5 9th Gen', '8 GB/512 GB SSD/Windows 10 Home/4 GB Graphics/NVIDIA GeForce GTX 1650 Max-Q', '52990.00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `gender` enum('Male','Female') COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=Active | 0=Inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `gender`, `phone`, `created`, `modified`, `status`) VALUES (1, 'as', 'as', 'as@as.as', 'f970e2767d0cfe75876ea857f92e319b', 'Male', '87654321', '2021-03-06 04:46:13', '2021-03-06 04:46:13', 1);
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `gender`, `phone`, `created`, `modified`, `status`) VALUES (2, 'as', 'sa', 'as@as.aa', 'f970e2767d0cfe75876ea857f92e319b', 'Male', '12', '2021-03-06 05:06:17', '2021-03-06 05:06:17', 1);
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `gender`, `phone`, `created`, `modified`, `status`) VALUES (3, 'sa', 'sa', 'sa@sa.sa', 'c12e01f2a13ff5587e1e9e4aedb8242d', 'Male', '312', '2021-03-06 05:19:56', '2021-03-06 05:19:56', 1);
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `gender`, `phone`, `created`, `modified`, `status`) VALUES (4, 'lk', 'lk', 'as@as.sa', 'f970e2767d0cfe75876ea857f92e319b', 'Male', '212', '2021-03-06 05:22:07', '2021-03-06 05:22:07', 1);
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `gender`, `phone`, `created`, `modified`, `status`) VALUES (9, 'sa', 'sa', 'sa@sa.saa', 'c12e01f2a13ff5587e1e9e4aedb8242d', 'Male', '584975', '2021-03-13 04:56:20', '2021-03-13 04:56:20', 1);
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `gender`, `phone`, `created`, `modified`, `status`) VALUES (10, '', 'as', 'as@as', 'f970e2767d0cfe75876ea857f92e319b', 'Male', '12', '2021-03-31 07:15:09', '2021-03-31 07:15:09', 1);
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `gender`, `phone`, `created`, `modified`, `status`) VALUES (11, '', 'as', 'as@as', 'f970e2767d0cfe75876ea857f92e319b', 'Male', '12', '2021-03-31 07:15:23', '2021-03-31 07:15:23', 1);


